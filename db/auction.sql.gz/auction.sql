-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2022 at 04:11 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `auction`
--

-- --------------------------------------------------------

--
-- Table structure for table `auction_history`
--

CREATE TABLE `auction_history` (
  `historyID` int(11) NOT NULL,
  `itemID` int(11) NOT NULL,
  `buyerID` int(11) NOT NULL,
  `bidAmount` int(11) NOT NULL,
  `bidTime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auction_history`
--

INSERT INTO `auction_history` (`historyID`, `itemID`, `buyerID`, `bidAmount`, `bidTime`) VALUES
(1, 2, 3, 202, '2021-11-05 14:39:15'),
(2, 2, 3, 204, '2021-11-05 14:04:10'),
(4, 3, 1, 202, '2021-11-06 13:56:02'),
(5, 3, 1, 256, '2021-11-06 13:59:35'),
(6, 3, 1, 258, '2021-11-06 14:00:51'),
(7, 2, 3, 206, '2021-11-06 14:03:12'),
(8, 5, 4, 220, '2022-02-05 08:56:27'),
(9, 7, 5, 1000, '2022-02-06 08:08:11'),
(10, 7, 6, 2000, '2022-02-06 08:10:07');

-- --------------------------------------------------------

--
-- Table structure for table `auction_item`
--

CREATE TABLE `auction_item` (
  `itemID` int(11) NOT NULL,
  `itemName` varchar(200) NOT NULL,
  `sellerID` int(11) NOT NULL,
  `itemType` varchar(10) NOT NULL,
  `startTime` datetime NOT NULL DEFAULT current_timestamp(),
  `endTime` datetime NOT NULL,
  `img` varchar(50) NOT NULL,
  `startingBid` int(11) NOT NULL,
  `incrementAmount` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` char(10) NOT NULL,
  `winningID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auction_item`
--

INSERT INTO `auction_item` (`itemID`, `itemName`, `sellerID`, `itemType`, `startTime`, `endTime`, `img`, `startingBid`, `incrementAmount`, `description`, `status`, `winningID`) VALUES
(2, 'electronic', 1, 'electronic', '2021-11-05 12:34:58', '2021-11-08 12:34:58', '6184d79ab41f35.12155487.png', 200, 2, 'abcd\r\ndefg', 'pending', 0),
(3, 'abc', 1, 'vehicle', '2021-11-05 12:41:10', '2021-11-07 12:41:10', '6184d90e2ba806.44502436.png', 200, 2, 'abc', 'pending', 0),
(5, 'abc', 1, 'watch', '2022-02-05 14:25:30', '2022-02-05 14:25:30', '61fe3b828268e6.85334184.jpg', 200, 20, 'abc\r\nabc', 'completed', 4),
(6, 'abc', 1, 'electronic', '2022-02-05 15:30:54', '2022-02-06 15:50:17', '61fe4ad652eb36.88959065.jpg', 200, 2, '1253', '', 0),
(7, 'abc', 1, 'watch', '2022-02-06 13:31:36', '2022-02-07 13:31:36', '61ff8060770a65.53946058.png', 200, 2, 'sfhr', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `mailID` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `priv` varchar(6) NOT NULL,
  `img` varchar(50) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `adhar_number` char(16) NOT NULL,
  `address` char(255) NOT NULL,
  `userName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `mailID`, `password`, `priv`, `img`, `mobile`, `adhar_number`, `address`, `userName`) VALUES
(1, 'hsb561110@gmail.com', '900150983cd24fb0d6963f7d28e17f72', 'seller', '618136db234f90.61658154.png', '9458982805', '12536245869578', 'chamoli   uttarakhand   246486', 'Harshvardhan Singh'),
(3, 'alpha@gmail.com', '900150983cd24fb0d6963f7d28e17f72', 'seller', '6184d44c5920e6.96694334.jpg', '7906278980', '1245658965893256', 'chamoli\r\nuttarakhand\r\n246486', 'alpha met'),
(4, 'hsb561110@gmail.comm', '900150983cd24fb0d6963f7d28e17f72', 'buyer', '61fe3a7ab6e6f4.10120099.jpg', '7905246598', '123562', 'chamoli\r\nuttarakhand\r\n246486', 'majifa soja'),
(5, 'shikharnawani42@gmail.com', '912ec803b2ce49e4a541068d495ab570', 'buyer', '61ff819033c582.07361529.png', '258', '14785', 'chamoli\r\nuttarakhand\r\n246486', 'shikhar'),
(6, 'asd@gmail.com', '912ec803b2ce49e4a541068d495ab570', 'buyer', '61ff8233eea777.00571876.png', '478', '147', 'chamoli\r\nuttarakhand\r\n246486', 'asd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auction_history`
--
ALTER TABLE `auction_history`
  ADD PRIMARY KEY (`historyID`);

--
-- Indexes for table `auction_item`
--
ALTER TABLE `auction_item`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auction_history`
--
ALTER TABLE `auction_history`
  MODIFY `historyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `auction_item`
--
ALTER TABLE `auction_item`
  MODIFY `itemID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
