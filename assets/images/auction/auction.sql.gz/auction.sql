-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2021 at 06:34 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `auction`
--

-- --------------------------------------------------------

--
-- Table structure for table `auction_history`
--

CREATE TABLE `auction_history` (
  `historyID` int(11) NOT NULL,
  `itemID` int(11) NOT NULL,
  `buyerID` int(11) NOT NULL,
  `bidAmount` int(11) NOT NULL,
  `bidTime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auction_history`
--

INSERT INTO `auction_history` (`historyID`, `itemID`, `buyerID`, `bidAmount`, `bidTime`) VALUES
(1, 2, 3, 202, '2021-11-05 14:39:15'),
(2, 2, 3, 204, '2021-11-05 14:04:10'),
(4, 3, 1, 202, '2021-11-06 13:56:02'),
(5, 3, 1, 256, '2021-11-06 13:59:35'),
(6, 3, 1, 258, '2021-11-06 14:00:51'),
(7, 2, 3, 206, '2021-11-06 14:03:12'),
(8, 3, 4, 260, '2021-11-06 15:41:12'),
(9, 22, 1, 26400, '2021-11-09 06:40:13');

-- --------------------------------------------------------

--
-- Table structure for table `auction_item`
--

CREATE TABLE `auction_item` (
  `itemID` int(11) NOT NULL,
  `itemName` varchar(200) NOT NULL,
  `sellerID` int(11) NOT NULL,
  `itemType` varchar(10) NOT NULL,
  `startTime` datetime NOT NULL DEFAULT current_timestamp(),
  `endTime` datetime NOT NULL,
  `img` varchar(50) NOT NULL,
  `startingBid` int(11) NOT NULL,
  `incrementAmount` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auction_item`
--

INSERT INTO `auction_item` (`itemID`, `itemName`, `sellerID`, `itemType`, `startTime`, `endTime`, `img`, `startingBid`, `incrementAmount`, `description`, `status`) VALUES
(2, 'electronic', 1, 'electronic', '2021-11-05 12:34:58', '2021-11-08 12:34:58', '6184d79ab41f35.12155487.png', 200, 2, 'abcd\r\ndefg', 'pending'),
(3, 'abc', 1, 'vehicle', '2021-11-05 12:41:10', '2021-11-07 12:41:10', '6184d90e2ba806.44502436.png', 200, 2, 'abc', 'pending'),
(6, 'Ring', 4, 'jewellery', '2021-11-06 21:40:29', '2022-01-05 21:40:29', '6186a8f577e304.40994394.jpg', 15000, 200, 'ssf', ''),
(7, 'Gold Necklaces', 4, 'jewellery', '2021-11-07 10:14:05', '2022-01-06 10:14:05', '6187599527d916.26890481.png', 23000, 500, 'Modern Gold Jewellery Design', ''),
(8, 'Gold Necklaces', 4, 'jewellery', '2021-11-07 10:18:55', '2022-01-21 10:18:55', '61875ab74901d8.32742830.jpg', 25000, 250, 'Modern Gold Jewellery Design with Earrings', ''),
(9, 'Gold Necklaces', 4, 'jewellery', '2021-11-07 10:36:09', '2022-01-08 10:36:09', '61875ec1bd09d3.79971961.jpg', 22000, 200, '40 Gram gold', ''),
(10, 'Gold Necklaces', 4, 'jewellery', '2021-11-07 10:49:33', '2022-01-08 10:49:33', '618761e50685f0.44821781.png', 21000, 150, '40 gram Gold ', ''),
(11, 'Gold Necklaces', 4, 'jewellery', '2021-11-07 10:52:19', '2022-01-11 10:52:19', '6187628bd1a992.58071141.png', 18999, 150, '40 gram Gold ', ''),
(12, 'Gold Necklaces', 4, 'jewellery', '2021-11-07 11:01:36', '2022-01-11 11:01:36', '618764b85e3b51.25131220.jpg', 26000, 200, 'Nacklace with earring', ''),
(13, 'Gold Necklaces', 4, 'jewellery', '2021-11-07 11:05:49', '2022-01-10 11:05:49', '618765b5d20c24.82342509.png', 22999, 200, 'Modern Design Necklace', ''),
(14, 'Gold Necklaces', 4, 'jewellery', '2021-11-07 11:11:40', '2022-01-21 11:11:40', '618767149a6131.78802314.jpg', 45000, 300, '22 Carat Gold', ''),
(15, 'Gold Necklaces', 4, 'jewellery', '2021-11-07 11:19:03', '2022-01-12 11:19:03', '618768cf26d6d3.32570793.jpg', 25599, 200, 'Modern Design in 22 Carat Gold', ''),
(16, 'Gold Necklaces', 4, 'jewellery', '2021-11-07 11:22:55', '2022-01-12 11:22:55', '618769b78d22d1.94983511.jpg', 22000, 250, 'Gold Nacklaces & Gold Earrings', ''),
(17, 'Gold Necklaces', 4, 'jewellery', '2021-11-07 11:25:17', '2022-01-05 11:25:17', '61876a45a5b4d2.60659824.png', 20000, 250, '24 Carat Gold', ''),
(18, 'SMART WATCHES', 4, 'watch', '2021-11-07 13:39:07', '2022-01-14 13:39:07', '618789a3b88224.50002323.png', 2500, 150, '33mm full touch color display / 5 ATM water-resistant design / 8 active sports mode / SpO2 Sensor.', ''),
(19, 'OnePlus ', 4, 'watch', '2021-11-07 13:52:32', '2022-01-15 13:52:32', '61878cc866a594.45663459.jpg', 14000, 150, 'Midnight Black: 46mm dial, Warp Charge, 110+ Workout Modes, Smartphone Music,SPO2 Health Monitoring & 5ATM + IP68 Water Resistance (Currently Android only)', ''),
(20, 'Titan', 4, 'watch', '2021-11-07 18:16:23', '2022-01-05 18:16:23', '6187ca9f0d7982.70778472.png', 8900, 150, 'Titan Analog Black Dial Men\'s Watch-1829NM02', ''),
(21, 'Titan Raga', 4, 'watch', '2021-11-07 18:35:58', '2022-02-04 18:35:58', '6187cf3679be00.95563909.jpg', 2500, 200, 'Dial Color: White, Case Shape: Oval. The case thickness is 7.50 mm\r\nBand Color: Silver, Band Material: Stainless Steel\r\nWatch Movement Type: Quartz, Watch Display Type: Analog', ''),
(22, 'Canon EOS 3000D DSLR Camera 1 Camera Body, 18 - 55 mm Lens  (Black)', 4, 'electronic', '2021-11-08 14:31:53', '2022-02-05 14:31:53', '6188e78173c6d5.82622645.jpeg', 25999, 400, 'Self-Timer | Type C and Mini HDMI, |9 Auto Focus Points | 35x Optical Zoom., Effective Pixels: 18 MP APS-C CMOS sensor-which is 25 times larger than a typical Smartphone sensor., WiFi | Full HD | Video Recording at 1080 p on 30fps.\r\nEffective Pixels: 18 M', ''),
(23, 'Lloyd 1.25 Ton 3 Star Split Inverter AC - White  (GLS15I36WRBP, Copper Condenser)', 4, 'electronic', '2021-11-08 14:46:06', '2022-01-25 14:46:06', '6188ead614a338.74755451.jpg', 29999, 350, 'Condenser coil: Copper\r\nPower Consumption: 1440 W\r\nNoise level: 40 dB\r\nAmbient Temperature: 52 degree C\r\nWi-Fi Enable: No', ''),
(24, 'Godrej 236 L Frost Free Double Door 2 Star Refrigerator', 4, 'electronic', '2021-11-08 15:14:25', '2022-01-16 15:14:25', '6188f1791521e1.89155991.jpeg', 19000, 250, 'Inverter Compressor\r\n2 Star: For Energy saving up to 30%\r\nToughened Glass Shelves\r\n236 L: Good for families of 3-5 members\r\nBuild in Stabilizer\r\n2021 BEE Rating Year\r\n\r\n', ''),
(25, 'PHILIPS HD7432/20 7 Cups Coffee Maker  (Black)', 4, 'electronic', '2021-11-08 15:41:28', '2022-01-12 15:41:28', '6188f7d060f3e2.58156022.jpeg', 3440, 150, 'Type: Drip Coffee Machine\r\nCapacity: 7 Cups', ''),
(26, 'Godrej 8 kg Fully Automatic Front Load with In-built Heater Silver  (WF EON 8014 PASC SV)', 4, 'electronic', '2021-11-08 16:00:00', '2022-02-04 16:00:00', '6188fc283bd355.15731825.jpeg', 34990, 300, 'Fully Automatic Front Load Washing Machines have Great Wash Quality with very less running cost\r\n\r\n1400 rpm : Higher the spin speed, lower the drying time\r\n\r\nNumber of wash programs - 15\r\n\r\n8 kg', ''),
(27, 'Panasonic 20 L Grill Microwave Oven  (NN-GT221WFDG, White)', 4, 'electronic', '2021-11-08 16:07:00', '2022-01-15 16:07:00', '6188fdccc1bd27.53792239.jpeg', 7000, 300, '20 L : Great for a family of 3\r\n\r\nGrill : Can be used for grilling along with defrosting, reheating and cooking food\r\n\r\nTouch Key Pad (Membrane) is sensitive to touch and easy to clean\r\n\r\nChild Lock : Ensures complete safety especially for homes with smal', ''),
(28, 'Mi 5X 138.8 cm (55 inch) Ultra HD (4K) LED Smart Android TV with Dolby Atmos and Dolby Vision', 4, 'electronic', '2021-11-08 16:12:09', '2022-01-26 16:12:09', '6188ff010bccf6.92649999.jpeg', 45500, 500, 'Supported Apps: Netflix|Prime Video|Disney+Hotstar|Youtube\r\n\r\nOperating System: Android (Google Assistant & Chromecast in-built)\r\n\r\nResolution: Ultra HD (4K) 3840 x 2160 Pixels\r\n\r\nSound Output: 40 W\r\n\r\nRefresh Rate: 60 Hz', ''),
(29, 'SONY X74 Bravia 125.7 cms (50 inch) Ultra HD (4K) LED Smart Android TV  (KD-50X74)', 4, 'electronic', '2021-11-08 16:16:00', '2022-02-15 16:16:00', '6188ffe897a308.88317405.jpeg', 60000, 600, 'Supported Apps: Netflix|Prime Video|Disney+Hotstar|Youtube\r\n\r\nOperating System: Android (Google Assistant & Chromecast in-built)\r\n\r\nResolution: Ultra HD (4K) 3840 x 2160 Pixels\r\n\r\nSound Output: 20 W\r\n\r\nRefresh Rate: 50 Hz', ''),
(30, 'Logitech G502 Lightspeed Wireless Optical Gaming Mouse  (2.4GHz Wireless, Black)', 4, 'electronic', '2021-11-08 16:26:03', '2022-02-03 16:26:03', '6189024382b056.08641506.jpeg', 10950, 200, 'Wireless\r\n\r\nFor Gaming\r\n\r\nInterface: 2.4GHz Wireless\r\n\r\nOptical Mouse', ''),
(31, 'acer Aspire 7 Core i5 10th Gen', 4, 'electronic', '2021-11-08 16:41:42', '2022-02-15 16:41:42', '618905eed6b3f4.05336669.jpeg', 48000, 800, 'RAM: 8 GB\r\n\r\nMemory: 512 GB SSD\r\n\r\nOS: Windows 10 Home\r\n\r\nGraphics Card: 4 GB Graphics/NVIDIA GeForce GTX 1650) \r\n \r\nGaming Laptop  (15.6 inch, Black, 2.15 Kg)', ''),
(32, 'amd Ryzen 7 5800X 3.8 GHz Upto 4.7 GHz AM4 Socket 8 Cores 16 Threads Desktop Processor  (Silver)', 4, 'electronic', '2021-11-08 16:49:21', '2022-01-25 16:49:21', '618907b999ced7.10871079.jpeg', 40000, 300, 'For Desktop\r\n\r\nOcta-Core\r\n\r\nAM4\r\n\r\nClock Speed: 3.8 GHz', ''),
(33, 'MICROSOFT 1V8-00006 Bluetooth Gamepad  (Carbon Black, For Xbox Series X, Xbox One X, Xbox One S, Xbox One, Windows 10, Android, iOS)', 4, 'electronic', '2021-11-08 16:54:53', '2022-02-04 16:54:53', '61890905768023.45686444.jpeg', 4000, 500, 'For Xbox Series X, Xbox One X, Xbox One S, Xbox One, Windows 10, Android, iOS\r\n\r\nOperating Range: 9 m\r\n\r\nWireless Gamepad', ''),
(34, 'FASTRACK FASTFIT WATCH WITH COOL GREY DIAL', 4, 'watch', '2021-11-08 19:49:40', '2022-01-25 19:49:40', '618931fc8b2c62.07287399.webp', 1500, 250, 'BRAND: Fastrack\r\n\r\nSTRAP MATERIAL: Silicone\r\n\r\nMOVEMENT: Quartz\r\n\r\nCASE MATERIAL: Plastic\r\n\r\nGLASS MATERIAL: Acrylic\r\n\r\nCASE THICKNESS: 12.55 mm\r\n\r\nCASE LENGTH(6H-12H): 54.00 mm\r\n\r\nDIAL COLOR: Grey', ''),
(35, 'GLITCH BLACK DIAL BLACK BRASS STRAP WATCH', 4, 'watch', '2021-11-08 19:53:49', '2022-01-25 19:53:49', '618932f59a8099.85427092.webp', 6000, 200, 'Fastrack Glitch Black Dial Analog Watch for Girls', ''),
(36, 'Rolls-Royce Phantom', 4, 'vehicle', '2021-11-09 15:13:34', '2022-02-16 15:13:34', '618a42c6a24430.30484820.webp', 90000000, 50000, 'Mileage (upto): 9.8 kmpl\r\n\r\nEngine (upto): 6749 cc\r\n\r\nBHP: 563.0', ''),
(37, 'Bentley Mulsanne', 4, 'vehicle', '2021-11-09 15:23:43', '2022-02-06 15:23:43', '618a4527d86ed0.13569585.jpg', 60000000, 35000, 'Mileage (upto): 10.1 kmpl\r\n\r\nEngine (upto): 6752 cc\r\n\r\nBHP: 506.0\r\n\r\nTransmission: Automatic\r\n\r\nBoot Space: 410-litres\r\n\r\nAirbags: yes', ''),
(38, 'Rolls-Royce Cullinan', 4, 'vehicle', '2021-11-09 15:31:49', '2022-02-06 15:31:49', '618a470d048245.19892757.jpg', 60000000, 40000, 'Mileage (upto): 9.5 kmpl\r\n\r\nEngine (upto): 6750 cc\r\n\r\nBHP: 563.0\r\n\r\nTransmission: Automatic\r\n\r\nSeats: 5\r\n\r\nBoot Space: 560-litres', ''),
(39, 'Bentley Bentayga', 4, 'vehicle', '2021-11-09 15:36:33', '2022-01-26 15:36:33', '618a4829c77521.62238456.jpg', 35000000, 25000, 'Mileage (upto): 11.11 kmpl\r\n\r\nEngine (upto): 5950 cc\r\n\r\nBHP: 600.0\r\n\r\nTransmission: Automatic\r\n\r\nBoot Space: 484-litres\r\n\r\nAirbags: yes', ''),
(40, 'Lamborghini Urus', 4, 'vehicle', '2021-11-09 15:40:25', '2022-01-23 15:40:25', '618a4911854098.26650814.jpg', 32500000, 15000, 'Mileage (upto): 7.87 kmpl\r\n\r\nEngine (upto): 3996 cc\r\n\r\nBHP: 641.0\r\n\r\nTransmission: Automatic\r\n\r\nSeats: 5\r\n\r\nBoot Space: 616 litres', ''),
(41, 'Aston Martin Rapide', 4, 'vehicle', '2021-11-09 16:02:29', '2022-01-02 16:02:29', '618a4e3d233cf7.21986453.jpg', 10000000, 15000, 'Mileage (upto): 10.9 kmpl\r\n\r\nEngine (upto): 5935 cc\r\n\r\nBHP: 552.0\r\n\r\nTransmission: Automatic\r\n\r\nBoot Space: 397-litres\r\n\r\nAirbags: yes', ''),
(42, 'Land Rover Range Rover', 4, 'vehicle', '2021-11-09 20:44:20', '2022-01-27 20:44:20', '618a904ce75c37.41954503.jpg', 25000000, 275, 'Mileage (upto): 13.33 kmpl\r\n\r\nEngine (upto): 2995 cc\r\n\r\nBHP: 557.86\r\n\r\nTransmission: Automatic\r\n\r\nSeats: 5\r\n\r\nBoot Space: 909-litres', ''),
(43, 'Volvo XC90', 4, 'vehicle', '2021-11-09 20:59:48', '2022-01-31 20:59:48', '618a93ec987057.95250398.jpg', 9000000, 15000, 'Mileage (upto): 46.0 kmpl\r\n\r\nEngine (upto): 1969 cc\r\n\r\nBHP: 400.0\r\n\r\nTransmission: Automatic\r\n\r\nSeats: 4, 7\r\n\r\nBoot Space: 300-litres', ''),
(44, 'Mercedes-Benz S-Class', 4, 'vehicle', '2021-11-09 21:05:19', '2022-01-17 21:05:19', '618a953744b067.96659103.jpg', 10000000, 27000, 'Mileage (upto): 14.3 kmpl\r\n\r\nEngine (upto): 5980 cc\r\n\r\nBHP: 630.0\r\n\r\nTransmission: Automatic\r\n\r\nBoot Space: 560 litres\r\n\r\nAirbags: yes', ''),
(45, 'Yamaha YZF R15 V4', 4, 'vehicle', '2021-11-09 21:34:48', '2022-01-15 21:34:48', '618a9c20c93f96.98054999.jpeg', 170500, 5000, 'Engine Capacity: 155 cc\r\n\r\nMileage: 45 kmpl\r\n\r\nTransmission: 6 Speed Manual\r\n\r\nKerb Weight: 142 kg\r\n\r\nFuel Tank Capacity: 11 litres\r\n\r\nSeat Height: 815 mm', ''),
(46, 'Bajaj Pulsar N250', 4, 'vehicle', '2021-11-09 21:47:23', '2021-12-22 21:47:23', '618a9f13614051.10779031.webp', 135000, 6000, 'Engine Capacity: 249.07 cc\r\n\r\nTransmission: 5 Speed Manual\r\n\r\nKerb Weight: 162 kg\r\n\r\nFuel Tank Capacity: 14 litres\r\n\r\nSeat Height: 795 mm\r\n\r\nMax Power: 24.1bhp', ''),
(47, 'KTM 790 Duke ', 4, 'vehicle', '2021-11-10 06:48:52', '2022-01-30 06:48:52', '618b1dfc94d324.10231036.jpg', 7000000, 6000, 'Fully coloured instrumentation with Bluetooth connectivity\r\n\r\nFull LED lighting system\r\n\r\n799cc parallel twin engine pumping out 105hp', ''),
(48, 'KTM 390 Duke', 4, 'vehicle', '2021-11-10 06:54:29', '2022-01-07 06:54:29', '618b1f4d7b1435.39722484.jpg', 2500000, 4500, 'LED headlight\r\n\r\nSwitchable ABS that can also be separately turned off just for the rear wheel\r\n\r\nDigital TFT display', ''),
(49, 'Analog Digital Multifunctional Black Dial W321BLK Outdoor Sports Digital Watch - For Men', 4, 'watch', '2021-11-10 07:21:11', '2021-12-25 07:21:11', '618b258fa03875.29109207.jpeg', 1000, 200, 'Strap Color: Black\r\n\r\nStrap Material: Silicone Rubber Strap\r\n\r\nStrap Design: Mesh\r\n\r\nCase/Bezel Material: Plastic\r\nWater Resistance Depth: 30\r\n\r\nPower Source: Battery Powered\r\n\r\nLight: Yes', ''),
(50, 'LXM-786 New Branded & Stylish Fab Combo Of Black Avenger Dial & Black PU Belt Watch and King Bracelet Analog Watch', 4, 'watch', '2021-11-10 07:28:06', '2022-01-17 07:28:06', '618b272e1b13a7.44532956.jpeg', 1500, 250, 'Mechanism: Quartz\r\n\r\nStrap Color: Black\r\n\r\nStrap Material: Metal Strap\r\n\r\nStrap Type: Linked\r\n\r\nCase/Bezel Material: Stainless Steel\r\n\r\nPower Source: Battery Powered\r\n\r\nClasp Type: Buckle', ''),
(51, 'Steel Chain Sports Design Adjustable Length Blue Dial Analog Watch - For Men New Sport watch Avio Steel Chain Analog Watch - For Men Analog Watch', 4, 'watch', '2021-11-10 07:30:03', '2022-01-07 07:30:03', '618b27a36c75c1.90864578.jpeg', 2000, 300, '123', ''),
(52, 'EX492 Edifice ( EFR-559DC-1BVUDF ) Analog Watch', 4, 'watch', '2021-11-10 07:36:23', '2022-01-15 07:36:23', '618b291f5166a7.17277101.jpeg', 11999, 800, 'Water Resistant: Yes\r\n\r\nDisplay Type: Analog\r\n\r\nStyle Code: EX492\r\n\r\nSeries: Edifice ( EFR-559DC-1BVUDF )\r\n\r\nOccasion: Casual\r\n\r\nWatch Type: Wrist Watch, Thick Straps, Metallic', ''),
(53, 'Anne Klein  NBAK3266BKRG Analog Watch', 4, 'watch', '2021-11-10 07:40:29', '2022-01-30 07:40:29', '618b2a15098406.82418737.jpeg', 9999, 670, 'Display Type: Analog\r\n\r\nStyle Code: NBAK3266BKRG\r\n\r\nOccasion: Casual\r\n\r\nWatch Type: Wrist Watch\r\n\r\nStrap Color: Black\r\n\r\nDial Color: Black', ''),
(54, 'TOMMY HILFIGER  TH1791688 Analog Watch', 4, 'watch', '2021-11-10 07:43:48', '2022-01-19 07:43:48', '618b2adc9d65a0.14562470.jpeg', 10999, 750, 'Display Type: Analog\r\n\r\nStyle Code: TH1791688\r\n\r\nOccasion: Casual\r\n\r\nWatch Type: Wrist Watch', ''),
(55, 'Wilson Profile XD Men\'s Package Golf Set', 4, 'sport', '2021-11-10 19:59:34', '2022-01-09 19:59:34', '618bd74ea9e9f3.10992191.jpg', 25000, 300, 'Colour: Red/Silver\r\n\r\nGolf Club Flex :Regular\r\n\r\nHand Orientation: Right\r\n\r\nGolf Club Loft: 10.5 Degree', ''),
(56, '2 Rupees Coin', 4, 'coin', '2021-11-11 14:03:10', '2021-12-30 14:03:10', '618cd5463a25f4.25938380.jpeg', 2000, 200, 'Issuer: India\r\n \r\nPeriod: Republic (1950-date)\r\n\r\nType: Standard circulation coin\r\n\r\nYears: 1992-2004\r\n\r\nValue: 2 Rupees (2 INR)\r\n\r\nCurrency: Rupee (decimalized, 1957-date)\r\n\r\nComposition: Copper-nickel\r\n\r\nWeight: 6 g\r\n\r\nDiameter: 26 mm\r\n\r\nThickness: 1.71', ''),
(57, '1 Rupees coin', 4, 'coin', '2021-11-11 14:14:52', '2021-12-28 14:14:52', '618cd804b84da4.37113783.jpg', 1500, 200, 'country: India\r\n\r\nDenomination: 1 rupee\r\n\r\nCoin type: Circulation coins\r\n\r\nComposition: Copper-Nickel\r\n\r\nEdge type: Reeded with a groove\r\n\r\nShape: Round\r\n\r\nAlignment: Medal (0°)\r\n\r\nWeight (gr): 8\r\n\r\nDiameter (mm): 28\r\n\r\nThickness (mm): 2', ''),
(58, '5 Rupees coin', 4, 'coin', '2021-11-11 14:29:05', '2022-01-05 14:29:05', '618cdb59286059.47431633.webp', 3000, 500, 'Issuer: India \r\n\r\nType: Circulating commemorative coin\r\n\r\nValue: 5 Rupees (5 INR)\r\n\r\nCurrency: Rupee (decimalized, 1957-date)\r\n\r\nComposition: Nickel brass\r\n\r\nWeight: 6.00 g\r\n\r\nDiameter: 23 mm\r\n\r\nShape: Round\r\n\r\nOrientation: Medal alignment ↑↑', ''),
(59, '10 Rupees coin', 4, 'coin', '2021-11-11 14:36:00', '2022-01-29 14:36:00', '618cdcf88db474.03815481.jpg', 2500, 250, 'Issuer: India \r\n\r\nType: Circulating commemorative coin\r\n\r\nValue: 10 Rupees (10 INR)\r\n\r\nCurrency: Rupee (decimalized, 1957-date)\r\n\r\nComposition: copper-nickel center in aluminium-bronze ring\r\n\r\nWeight: 7.71 g\r\n\r\nDiameter: 27 mm\r\n\r\nThickness: 1.8 mm\r\n\r\nShap', ''),
(60, '1/2 PICE YEAR 1939 GEORGE VI KING EMPEROR C', 4, 'coin', '2021-11-11 14:46:39', '2022-01-16 14:46:39', '618cdf772f8f95.55056151.jpg', 5000, 1000, 'Issuer: India - British \r\n\r\nKing: George VI (1936-1952)\r\n\r\nType: Standard circulation coin\r\n\r\nYears: 1938-1940\r\n\r\nValue: 1/2 Pice (1/128)\r\n\r\nCurrency: Rupee (1862-1947)\r\n\r\nComposition: Bronze\r\n\r\nWeight: 2.4 g\r\n\r\nDiameter: 21.1 mm\r\n\r\nShape: Round\r\n\r\nOrient', ''),
(61, '1 ANNA GEORGE VI KING YEAR 1943 RARE COIN', 4, 'coin', '2021-11-11 14:56:50', '2022-01-07 14:56:50', '618ce1da62c129.36410797.jpeg', 8000, 1500, 'Issuer: India - British \r\n\r\nKing: George VI (1936-1952)\r\n\r\nType: Standard circulation coin\r\n\r\nYears: 1942-1945\r\n\r\nValue: 1 Anna = 1/16 Rupee (1/16)\r\n\r\nCurrency: Rupee (1862-1947)\r\n\r\nComposition: Nickel brass\r\n\r\nWeight: 3.89 g\r\n\r\nDiameter: 20.5 mm\r\n\r\nThick', ''),
(62, '5 Rupees Note After Independence Rama Rao', 4, 'coin', '2021-11-11 15:40:32', '2022-02-06 15:40:32', '618cec1816a980.23279280.jpg', 5500, 800, '5 Rupees Note After Independence Rama Rao', ''),
(63, '50 Rupees Note', 4, 'coin', '2021-11-11 16:11:44', '2022-01-07 16:11:44', '618cf368a19443.63942552.jpg', 10000, 1500, 'India 50 Rupees (1983-84) (Parliament house', ''),
(64, '1 Rupees Note', 4, 'coin', '2021-11-11 16:14:35', '2022-01-05 16:14:35', '618cf413d2c5a4.09539326.jpg', 2500, 600, '1964 Government of India 1 Rupee Note Signed By S. Bhoothalingam, Very Rare', ''),
(65, '10 Rupees Note', 4, 'coin', '2021-11-11 16:22:13', '2022-01-08 16:22:13', '618cf5dd66cfd4.09613570.jpg', 12000, 2000, '10 Rupees Signed by B Rama Rau 1949-1957', ''),
(66, '2 Rupees Note', 4, 'coin', '2021-11-11 16:25:24', '2022-01-05 16:25:24', '618cf69cde3c05.84047060.jpg', 9000, 1000, '2 Rupees Note. Signed by I G Patel', ''),
(67, '20 Rupees Note ', 4, 'coin', '2021-11-11 16:28:33', '2022-01-03 16:28:33', '618cf759abc0c0.77240146.jpg', 4000, 500, '20 Rupees Note', ''),
(68, 'Cricket Ball signed by MS Dhoni', 4, 'sport', '2021-11-11 17:40:46', '2022-01-05 17:40:46', '618d08463e4ab1.80404787.jpg', 15000, 2000, 'Captain Cool Signed ball', ''),
(69, 'Football Signed by Ronaldo', 4, 'sport', '2021-11-11 17:45:40', '2022-01-28 17:45:40', '618d096cebee26.96982091.jpg', 17000, 3000, 'Ronaldo signed in Football', ''),
(70, 'Jersey signed by Jonah Lomu', 4, 'sport', '2021-11-11 17:57:03', '2021-12-27 17:57:03', '618d0c177ef080.29684188.jpg', 8000, 900, 'Jonah Lomu signed in Jersey', ''),
(71, 'Chess Board signed by Viswanathan Anand', 4, 'sport', '2021-11-11 18:04:53', '2022-01-14 18:04:53', '618d0ded00b2d0.15360555.jpg', 60000, 8000, 'Signed by  Indian chess grandmaster', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `mailID` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `priv` varchar(6) NOT NULL,
  `img` varchar(50) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `adhar_number` char(16) NOT NULL,
  `address` char(255) NOT NULL,
  `userName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `mailID`, `password`, `priv`, `img`, `mobile`, `adhar_number`, `address`, `userName`) VALUES
(1, 'hsb561110@gmail.com', 'e2fc714c4727ee9395f324cd2e7f331f', 'seller', '618136db234f90.61658154.png', '9458982805', '12536245869578', 'chamoli   uttarakhand   246486', 'Harshvardhan Singh'),
(3, 'alpha@gmail.com', '900150983cd24fb0d6963f7d28e17f72', 'seller', '6184d44c5920e6.96694334.jpg', '7906278980', '1245658965893256', 'chamoli\r\nuttarakhand\r\n246486', 'alpha met'),
(4, 'manish@gmail.com', 'c20ad4d76fe97759aa27a0c99bff6710', 'seller', '6186a07cebd974.25648303.png', '7060413378', '112354548', '1ddd', 'Manu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auction_history`
--
ALTER TABLE `auction_history`
  ADD PRIMARY KEY (`historyID`);

--
-- Indexes for table `auction_item`
--
ALTER TABLE `auction_item`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auction_history`
--
ALTER TABLE `auction_history`
  MODIFY `historyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `auction_item`
--
ALTER TABLE `auction_item`
  MODIFY `itemID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
